"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require('node:fs');
checkConfigFile();
const path = require("path");
require('dotenv').config({
    path: path.join(__dirname, '../config'),
    quiet: true
});
const http_status_codes_1 = require("http-status-codes");
const fastify_1 = __importDefault(require("fastify"));
const moment_1 = __importDefault(require("moment"));
const nodecron_1 = __importDefault(require("./nodecron"));
const serveStatic = require('serve-static');
var crypto = require('crypto');
const utils_1 = require("./utils/utils");
const authenticate_1 = require("./middleware/authenticate");
const stream_1 = require("stream");
const mqtt_1 = require("./middleware/mqtt");
const helmet = require("@fastify/helmet");
var serverOption = {};
if (process.env.SSL_ENABLE && process.env.SSL_ENABLE == '1' && process.env.SSL_KEY) {
    serverOption = {
        logger: {
            level: 'error',
        },
        ignoreTrailingSlash: true,
        bodyLimit: 20 * 1024 * 1024,
        https: {
            key: fs.readFileSync(process.env.SSL_KEY),
            cert: fs.readFileSync(process.env.SSL_CRT)
        }
    };
}
else {
    serverOption = {
        logger: {
            level: 'error',
        },
        ignoreTrailingSlash: true,
        bodyLimit: 20 * 1024 * 1024,
        connectionTimeout: 10000
    };
}
const app = (0, fastify_1.default)(serverOption);
const { name, version, subVersion } = require('./../package.json');
global.appDetail = { name, subVersion, version };
app.register(require('@fastify/formbody'));
app.register(require('@fastify/cors'), {
    origin: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'localkey', 'content-encoding', 'content-length', 'source-agent', 'client-ip', 'uid'],
    credentials: true,
    strictPreflight: false,
    allowPrivateNetwork: true
});
app.register(require('fastify-no-icon'));
app.register(helmet, {
    crossOriginResourcePolicy: { policy: 'cross-origin' }
});
app.register(require('@fastify/rate-limit'), {
    max: +process.env.MAX_CONNECTION_PER_MINUTE || 1000,
    timeWindow: '1 minute'
});
app.register(serveStatic(path.join(__dirname, '../public')));
app.register(require('@fastify/view'), {
    engine: {
        ejs: require('ejs')
    }
});
app.register(require('@fastify/jwt'), {
    secret: process.env.SECRET_KEY
});
global.apiStartTime = (0, moment_1.default)().format('YYYY-MM-DD HH:mm:ss');
global.mophService = require('./routes/main/crontab')(global.mophService, {});
global.firstProcessPid = 0;
global.mophService = null;
app.decorate("authenticate", async (request, reply) => {
    return (0, authenticate_1.authenticateRequest)(request, reply);
});
app.decorate("checkRequestKey", async (request, reply) => {
    let skey = null;
    if (request.headers.localkey) {
        skey = request.headers.localkey;
    }
    var requestKey = crypto.createHash('md5').update(process.env.REQUEST_KEY).digest('hex');
    if (!skey || skey !== requestKey) {
        return reply.send({
            statusCode: http_status_codes_1.StatusCodes.UNAUTHORIZED,
            message: (0, http_status_codes_1.getReasonPhrase)(http_status_codes_1.StatusCodes.UNAUTHORIZED) + ' or invalid key'
        });
    }
});
var geoip = require('geoip-lite');
app.addHook('preParsing', async (request, reply, payload) => {
    const contentEncoding = request.headers['content-encoding'];
    const contentLength = request.headers['content-length'];
    if (contentEncoding && contentEncoding.toLowerCase() === 'gzip' &&
        contentLength && parseInt(contentLength) > 0) {
        const chunks = [];
        for await (const chunk of payload) {
            chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        }
        if (chunks.length === 0)
            return payload;
        const compressed = Buffer.concat(chunks);
        const decompressed = await (0, utils_1.unGzip)(compressed);
        const readable = new stream_1.Readable();
        readable.push(decompressed);
        readable.push(null);
        return readable;
    }
    return payload;
});
app.addHook('onRequest', async (req, reply) => {
    const unBlockIP = process.env.UNBLOCK_IP || '??';
    let ipAddr = req.headers["x-forwarded-for"] || req.headers["x-real-ip"] || req.ip;
    req.clientIP = ipAddr;
    ipAddr = ipAddr ? ipAddr.split(',') : [''];
    ipAddr = ipAddr[0].split(':');
    req.ipAddr = ipAddr[0].trim();
    req.ipAddr = req.ipAddr || req.clientIP;
    let isSubnet = true;
    if (process.env?.ALLOW_API_SUBNET || false) {
        isSubnet = await isIPInSubnet(req.clientIP);
    }
    var geo = geoip.lookup(req.ipAddr);
    req.geo = geo;
    if (!isSubnet && geo && geo.country && geo.country != 'TH' && req.ipAddr != process.env.HOST && !unBlockIP.includes(req.ipAddr)) {
        console.log(req.ipAddr, `Unacceptable country: ${geo.country}`);
        return reply.send({ status: http_status_codes_1.StatusCodes.NOT_ACCEPTABLE, ip: req.ipAddr, message: (0, http_status_codes_1.getReasonPhrase)(http_status_codes_1.StatusCodes.NOT_ACCEPTABLE) });
    }
});
app.addHook('preHandler', async (request, reply) => {
    console.log((0, moment_1.default)().format('HH:mm:ss.SSS'), request.ipAddr, request?.geo?.country || 'unk', request.method, request.url);
});
app.addHook('onSend', async (request, reply, payload) => {
    const headers = {
        "Cache-Control": "no-store",
        Pragma: "no-cache",
        src: `HIS-Connect ${version || ''}-${subVersion || ''}`
    };
    reply.headers(headers);
    return payload;
});
app.setErrorHandler((error, request, reply) => {
    request.log?.error(error);
    console.error(`   ❌ Unhandled error on ${request.method} ${request.url}:`, error?.message || error);
    const statusCode = error?.statusCode && error.statusCode >= 400 && error.statusCode < 600 ? error.statusCode : 500;
    reply.status(statusCode).send({
        statusCode,
        error: 'Internal Server Error',
        message: statusCode === 500 ? 'Internal Server Error' : (error?.message || 'Internal Server Error')
    });
});
app.register(require('./route'));
app.register(nodecron_1.default);
var options = {
    port: process.env.PORT || 3004,
    host: process.env.HOST || '0.0.0.0'
};
(async () => {
    await connectDB();
    await mqttSubscribe();
    app.listen(options, (err) => {
        if (err)
            throw err;
        const instanceId = process.env.NODE_APP_INSTANCE || '0';
        console.info(`${(0, moment_1.default)().format('HH:mm:ss')} HIS-Connect API ${global.appDetail.version}-${global.appDetail.subVersion} started on port ${options.port}, PID: ${process.pid} with NodeJS: ${process.version || ''}, Instance: ${instanceId}`);
    });
})();
async function connectDB() {
    const dbConnection = require('./plugins/db');
    await connectHIS(dbConnection);
    await connectISOnline(dbConnection);
}
async function connectHIS(dbConnection) {
    const dbClient = process.env.HIS_DB_CLIENT;
    try {
        global.dbHIS = dbConnection('HIS');
        let sql = '';
        switch (dbClient) {
            case 'oracledb':
                sql = 'SELECT CURRENT_TIMESTAMP AS "date" FROM dual';
                break;
            case 'mssql':
                sql = 'SELECT SYSDATETIME() AS date';
                break;
            default:
                sql = 'SELECT NOW() as date';
        }
        const result = await global.dbHIS.raw(sql);
        let date;
        if (dbClient === 'pg' || dbClient === 'postgres' || dbClient === 'postgresql') {
            date = result.rows?.[0]?.date;
        }
        else if (dbClient === 'mssql') {
            date = result.recordset?.[0]?.date;
        }
        else if (dbClient === 'oracledb') {
            date = result[0]?.[0]?.date;
        }
        else {
            date = result[0]?.[0]?.date;
        }
        console.info(`   🔗 PID:${process.pid} >> HIS DB server '${dbClient}' connected, date/time on DB server:`, (0, moment_1.default)(date).format('YYYY-MM-DD HH:mm:ss'));
    }
    catch (error) {
        console.error(`   ❌ PID:${process.pid} >> HIS DB server '${dbClient}' connect error: `, error.message);
    }
}
async function connectISOnline(dbConnection) {
    try {
        global.dbIs = dbConnection('ISONLINE');
        global.dbISOnline = global.dbIs;
    }
    catch (error) {
        console.error(`   ❌ PID:${process.pid} >> ISONLINE DB server connect error: `, error.message);
    }
}
async function checkConfigFile() {
    if (fs.existsSync('./config')) {
        console.info(`✅ PID:${process.pid} >> Check local 'config' file exist: Successfully`);
    }
    else {
        console.error(`❌ PID:${process.pid} >> Check local 'config' file exist: Not found, please create file 'config' and try again.`);
        process.exit(1);
    }
}
async function isIPInSubnet(ip) {
    if (!ip || ip === '::1' || ip === '127.0.0.1' || ip === 'localhost') {
        return true;
    }
    let localIP = (0, utils_1.getIP)();
    if (!localIP || !localIP?.ip) {
        return true;
    }
    localIP = (localIP?.ip || '').split('.');
    const isValidIP = ip.includes(localIP.slice(0, 3).join('.'));
    return isValidIP;
}
const mqtt = new mqtt_1.Mqtt();
async function mqttSubscribe() {
    const instanceNo = process.env.NODE_APP_INSTANCE;
    if (instanceNo == '0') {
        await mqtt.mqttSubscribe();
    }
}
