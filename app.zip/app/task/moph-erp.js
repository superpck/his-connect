"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.erpAdminRequest = exports.updateAlive = exports.sendBedNo = exports.sendWardName = exports.mophErpProcessTask = exports.sendBedOccupancy = void 0;
const moment_1 = __importDefault(require("moment"));
const moph_refer_1 = require("../middleware/moph-refer");
const hismodel_1 = __importDefault(require("./../routes/his/hismodel"));
const os_1 = require("os");
const fs = require('fs');
const utils_1 = require("../utils/utils");
const packageJson = require('../../package.json');
const dbConnection = require('../plugins/db');
let db = dbConnection('HIS');
const hisProvider = process.env.HIS_PROVIDER || '';
const hisVersion = process.env.HIS_VERSION || '';
const hospcode = process.env.HOSPCODE || '';
let hospitalConfig = null;
const sendBedOccupancy = async (dateProcess = null) => {
    hospitalConfig = await (0, moph_refer_1.getHospitalConfig)();
    let whatUTC = Intl?.DateTimeFormat().resolvedOptions().timeZone || '';
    let currDate;
    if (whatUTC == 'UTC' || whatUTC == 'Etc/UTC') {
        currDate = (0, moment_1.default)().locale('TH').add(7, 'hours').subtract(1, 'hours').startOf('hour').format('YYYY-MM-DD HH:mm:ss');
    }
    else {
        currDate = (0, moment_1.default)().locale('TH').subtract(1, 'hours').startOf('hour').format('YYYY-MM-DD HH:mm:ss');
    }
    dateProcess = dateProcess ? (0, moment_1.default)(dateProcess).locale('TH').startOf('hour').format('YYYY-MM-DD HH:mm:ss') : null;
    let dateIPD = dateProcess || currDate;
    let opdResult = null;
    let wardResult = await sendBedOccupancyByWard(dateIPD);
    let clinicResult = await sendBedOccupancyByClinic(dateIPD);
    let dateOpd = dateProcess || currDate;
    do {
        [opdResult] = await Promise.all([
            sendOpdVisitByClinic(dateOpd)
        ]);
        dateOpd = (0, moment_1.default)(dateOpd).add(1, 'day').format('YYYY-MM-DD');
    } while (dateOpd <= currDate);
    console.log('-'.repeat(70));
    return { clinicResult, wardResult, opdResult };
};
exports.sendBedOccupancy = sendBedOccupancy;
const sendBedOccupancyByWard = async (date) => {
    try {
        const occupancy_date = (0, moment_1.default)(date).locale('TH').endOf('hour').format('YYYY-MM-DD HH:mm:ss');
        let rows = await hismodel_1.default.concurrentIPDByWard(db, date);
        if (rows && rows.length) {
            rows = rows.map((v) => {
                return {
                    ...v, occupancy_date,
                    date: (0, moment_1.default)(date).format('YYYY-MM-DD'),
                    hospcode,
                    his: hisProvider || ''
                };
            });
            const result = await (0, moph_refer_1.sendingToMoph)('/save-occupancy-rate-by-ward', rows);
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'send Occ Rate by ward', date, result.status || '', result.message || '', rows.length, 'rows');
        }
        console.log('-'.repeat(70));
        return rows;
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'sendBedOccupancyByWard', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.error((0, moment_1.default)().format('HH:mm:ss'), 'sendBedOccupancy error by ward', date, error.message);
        console.log('-'.repeat(70));
        return false;
    }
};
const sendBedOccupancyByClinic = async (date) => {
    try {
        let rows = await hismodel_1.default.concurrentIPDByClinic(db, date);
        if (rows && rows.length) {
            rows = rows.map(v => {
                return { ...v, date, hospcode, his: hisProvider || '' };
            });
            const result = await (0, moph_refer_1.sendingToMoph)('/save-occupancy-rate-by-clinic', rows);
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'send Occ rate by clinic', date, result.status || '', result.message || '', rows.length, 'rows');
        }
        return rows;
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'sendBedOccupancyByClinic', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.error((0, moment_1.default)().format('HH:mm:ss'), 'sendBedOccupancy by clinic error', date, error.message);
        return false;
    }
};
const sendOpdVisitByClinic = async (date) => {
    try {
        let rows = await hismodel_1.default.sumOpdVisitByClinic(db, date);
        if (rows && rows.length) {
            rows = rows.map((v) => {
                return {
                    ...v, hospcode, his: hisProvider || ''
                };
            });
            const result = await (0, moph_refer_1.sendingToMoph)('/save-sum-opd-visit-by-clinic', rows);
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'send Sum OPD visit by clinic', date, result.status || '', result.message || '', rows.length, 'rows');
        }
        return rows;
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'sendOpdVisitByClinic', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.error((0, moment_1.default)().format('HH:mm:ss'), 'sendSumOpdVisit by clinic error', date, error.message);
        return false;
    }
};
const mophErpProcessTask = async () => {
    let result = await (0, moph_refer_1.taskFunction)('MOPH-ERP');
    result = await (0, moph_refer_1.taskFunction)('sql', {
        function_name: 'getWard',
        his_name: hisProvider, his_version: hisVersion || ''
    });
    console.log('taskFunction', result);
    if (result?.statusCode == 200 && result?.row?.sql_string) {
        const sqlString = result.row.sql_string?.trim();
        console.log('get ward sql:', sqlString);
        if (sqlString) {
            try {
                let rows;
                const whereVariables = normalizeSqlWhereVariable(result.row?.sql_where_variable);
                if (/^db\s*\(/.test(sqlString)) {
                    let queryBuilder = new Function('db', '"use strict"; return (' + sqlString + ');')(db);
                    queryBuilder = applyWhereToBuilder(queryBuilder, whereVariables);
                    console.log('queryBuilder 1:', queryBuilder.toSQL().toNative());
                    rows = await queryBuilder;
                }
                else {
                    const { sql, bindings } = appendWhereClause(sqlString, whereVariables);
                    console.log('queryBuilder 2:', db.raw(sql, bindings).toSQL().toNative());
                    rows = bindings.length ? await db.raw(sql, bindings) : await db.raw(sqlString);
                }
                console.log(Array.isArray(rows) ? rows.length : rows);
            }
            catch (error) {
                console.error('execute sql_string error', error.message);
            }
        }
    }
};
exports.mophErpProcessTask = mophErpProcessTask;
const sendWardName = async () => {
    try {
        let rows = await hismodel_1.default.getWard(db);
        if (rows && rows.length) {
            rows = rows.map(v => {
                return { ...v, hospcode: process.env.HOSPCODE || '' };
            });
            const result = await (0, moph_refer_1.sendingToMoph)('/save-ward', rows);
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'sendWardName', result.status || '', result.message || '', rows.length, 'rows');
            console.log('-'.repeat(70));
            return result;
        }
        else {
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'sendWardName', 'No ward data');
            console.log('-'.repeat(70));
            return { statusCode: 200, message: 'No ward data' };
        }
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'sendWardName', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.log((0, moment_1.default)().format('HH:mm:ss'), 'getWard error', error.message);
        console.log('-'.repeat(70));
        return [];
    }
};
exports.sendWardName = sendWardName;
const sendBedNo = async () => {
    let result;
    let countBed = 0;
    try {
        if (typeof hismodel_1.default.countBedNo === 'function') {
            result = await hismodel_1.default.countBedNo(db);
            countBed = result?.total_bed || 0;
        }
        let error = '';
        let times = 0;
        let startRow = countBed < 500 ? -1 : 0;
        const limitRow = 500;
        let sentResult = [];
        do {
            let rows = await hismodel_1.default.getBedNo(db, null, startRow, limitRow);
            if (rows && rows.length) {
                rows = rows
                    .filter((row) => row.wardcode != null && row.wardcode != '')
                    .map((v) => {
                    return {
                        ...v, hospcode: hospcode,
                        hcode5: hospcode.length == 5 ? hospcode : null,
                        hcode9: hospcode.length == 9 ? hospcode : null
                    };
                });
                result = await (0, moph_refer_1.sendingToMoph)('/save-bed-no', rows);
                if (result?.status != 200 && result?.statusCode != 200) {
                    error = result?.message || result?.status || result?.statusCode || null;
                }
                sentResult.push({ startRow, limitRow, rows: rows.length, result });
            }
            startRow += limitRow;
            times++;
        } while (startRow < countBed && countBed != 0);
        console.log((0, moment_1.default)().format('HH:mm:ss'), `sendBedNo ${countBed} rows (${times} times)`, error);
        console.log('-'.repeat(70));
        return { statusCode: 200, sentResult };
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'sendBedNo', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.log((0, moment_1.default)().format('HH:mm:ss'), 'getBedNo error', error.message);
        console.log('-'.repeat(70));
        return { statusCode: error.status || 500, message: error.message || error };
    }
};
exports.sendBedNo = sendBedNo;
const updateAlive = async () => {
    const ipServer = (0, utils_1.getIP)();
    try {
        const apiEnv = await detectRuntimeEnvironment();
        let data = {
            api_date: global.apiStartTime,
            server_date: (0, moment_1.default)().format('YYYY-MM-DD HH:mm:ss'),
            hospcode,
            version: packageJson.version || '',
            subversion: packageJson.subVersion || '',
            port: process.env.PORT || 0,
            ip: ipServer.ip,
            host_type: apiEnv || 'host',
            nodejs: process.version || '',
            platform: (0, os_1.platform)() || '',
            os_version: (0, os_1.release)() || '',
            his: hisProvider, ssl: process.env?.SSL_ENABLE || 0,
        };
        const result = await (0, moph_refer_1.updateHISAlive)(data);
        const status = result.status == 200 || result.statusCode == 200 ? true : false;
        if (status) {
            console.log((0, moment_1.default)().format('HH:mm:ss'), '✅ Sent API Alive status result', result.status || '', result.statusCode || '', result?.message || '');
        }
        else {
            console.error((0, moment_1.default)().format('HH:mm:ss'), '❌ Sent API Alive status result', result.status || '', result.statusCode || '', result?.message || '');
        }
        console.log('-'.repeat(70));
        return result;
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'updateAlive', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.error((0, moment_1.default)().format('HH:mm:ss'), '❌ Sent API Alive status error:', error?.status || error?.statusCode || '', error?.message || error || '');
        console.log('-'.repeat(70));
        return [];
    }
};
exports.updateAlive = updateAlive;
const erpAdminRequest = async () => {
    try {
        const result = await (0, moph_refer_1.checkAdminRequest)();
        const rows = result?.rows || result?.data || [];
        if (rows && rows.length > 0) {
            let requestResult;
            for (let row of rows) {
                if (row.request_type == 'bed') {
                    requestResult = await (0, exports.sendBedNo)();
                    console.log((0, moment_1.default)().format('HH:mm:ss'), 'ERP admin request get bed no.', requestResult?.statusCode || requestResult?.status || '', requestResult?.message || '');
                }
                else if (row.request_type == 'ward') {
                    requestResult = await (0, exports.sendWardName)();
                    console.log((0, moment_1.default)().format('HH:mm:ss'), 'ERP admin request get ward name.', requestResult?.statusCode || requestResult?.status || '', requestResult?.message || '');
                }
                else if (row.request_type == 'alive') {
                    requestResult = await (0, exports.updateAlive)();
                    console.log((0, moment_1.default)().format('HH:mm:ss'), 'ERP admin request send alive status.', requestResult?.statusCode || requestResult?.status || '', requestResult?.message || '');
                }
                else if (row.request_type == 'occupancy') {
                    requestResult = await (0, exports.sendBedOccupancy)();
                    console.log((0, moment_1.default)().format('HH:mm:ss'), 'ERP admin request occupancy', requestResult?.statusCode || requestResult?.status || '', requestResult?.message || '');
                }
                const updateResult = await (0, moph_refer_1.updateAdminRequest)({
                    request_id: row.request_id,
                    status: requestResult?.statusCode == 200 || requestResult?.status == 200 ? 'success' : `failed ${requestResult?.status || requestResult?.statusCode || ''}`,
                    isactive: 0
                });
                console.log((0, moment_1.default)().format('HH:mm:ss'), 'ERP admin request update status', updateResult?.statusCode || updateResult?.status || '', updateResult?.message || '');
            }
        }
        else {
            console.log((0, moment_1.default)().format('HH:mm:ss'), 'No admin request', result.status || result?.statusCode || '', result?.data?.message || result?.message || '');
        }
        console.log('-'.repeat(70));
        return result;
    }
    catch (error) {
        (0, moph_refer_1.sendingError)({
            route_name: 'erpAdminRequest', error_code: error.status || '500',
            error_message: error.message || ''
        });
        console.log((0, moment_1.default)().format('HH:mm:ss'), 'Admin Request error', error.message);
        console.log('-'.repeat(70));
        return [];
    }
};
exports.erpAdminRequest = erpAdminRequest;
function getCode9(hcode = hospcode) {
}
function normalizeSqlWhereVariable(input) {
    if (!input) {
        return {};
    }
    if (typeof input === 'string') {
        try {
            const parsed = JSON.parse(input);
            return typeof parsed === 'object' && parsed ? parsed : {};
        }
        catch (_error) {
            return {};
        }
    }
    if (typeof input === 'object') {
        return input;
    }
    return {};
}
function applyWhereToBuilder(queryBuilder, whereVariables) {
    if (!queryBuilder || typeof queryBuilder.where !== 'function') {
        return queryBuilder;
    }
    Object.entries(whereVariables).forEach(([key, value]) => {
        if (value === undefined || value === null || value === '') {
            return;
        }
        const column = toSnakeCase(key);
        queryBuilder.where(column, value);
    });
    return queryBuilder;
}
function appendWhereClause(sqlString, whereVariables) {
    const activeFilters = Object.entries(whereVariables).filter(([_, value]) => value !== undefined && value !== null && value !== '');
    if (!activeFilters.length) {
        return { sql: sqlString, bindings: [] };
    }
    const hasWhere = /\bwhere\b/i.test(sqlString);
    const bindings = [];
    const conditions = activeFilters.map(([key, value]) => {
        bindings.push(value);
        return `${toSnakeCase(key)} = ?`;
    });
    const clause = conditions.join(' AND ');
    const separator = hasWhere ? ' AND ' : ' WHERE ';
    return { sql: sqlString + separator + clause, bindings };
}
function toSnakeCase(value) {
    if (!value) {
        return value;
    }
    return value.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();
}
async function detectRuntimeEnvironment() {
    let env = "host";
    if (fs.existsSync("/.dockerenv")) {
        env = "docker";
    }
    else {
        try {
            const cgroup = fs.readFileSync("/proc/1/cgroup", "utf8");
            if (/docker|containerd/i.test(cgroup)) {
                env = "docker";
            }
            if (/kubepods/i.test(cgroup)) {
                env = "kubernetes";
            }
        }
        catch { }
    }
    const r = (0, os_1.release)().toLowerCase();
    try {
        const version = fs.readFileSync("/proc/version", "utf8").toLowerCase();
        if (r.includes("microsoft") ||
            r.includes("wsl") ||
            version.includes("microsoft")) {
            env = "wsl";
        }
    }
    catch { }
    return env;
}
