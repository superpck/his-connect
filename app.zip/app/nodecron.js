"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = cronjob;
const moment_1 = __importDefault(require("moment"));
const child_process_1 = require("child_process");
const moph_erp_1 = require("./task/moph-erp");
const moph_iot_1 = __importDefault(require("./task/moph-iot"));
const moph_alert_1 = require("./task/moph-alert");
const moph_starter_1 = __importDefault(require("./task/moph-starter"));
const moph_appointment_1 = __importDefault(require("./task/moph-appointment"));
const shell = require("shelljs");
const cron = require('node-cron');
const referCrontab = require('./routes/refer/crontab');
const instanceId = process.env.NODE_APP_INSTANCE ? +process.env.NODE_APP_INSTANCE + 1 : null;
const cronjobStartupTimeoutMs = Math.max(1000, +(process.env.CRONJOB_STARTUP_TIMEOUT_MS || 12000));
let hospitalConfig = null;
let onProcess = {};
const processState = {
    firstProcessPid: 0,
    pm2Name: 'unknown',
    pm2List: [],
    isFirstProcess: false
};
const pm2Cache = {
    processes: [],
    lastUpdate: 0,
    ttl: 30000
};
const jobQueue = {
    sendNRefer: { isRunning: false },
    sendNReferIPD: { isRunning: false },
    sendISOnline: { isRunning: false },
};
function getTimestamp() {
    return (0, moment_1.default)().format('HH:mm:ss');
}
function getErrorMessage(error) {
    return error?.message || String(error);
}
function withTimeout(promise, timeoutMs, label) {
    return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            reject(new Error(`${label} exceeded ${timeoutMs}ms`));
        }, timeoutMs);
        promise
            .then((result) => {
            clearTimeout(timeout);
            resolve(result);
        })
            .catch((error) => {
            clearTimeout(timeout);
            reject(error);
        });
    });
}
function getMinutesSinceMidnight() {
    return (0, moment_1.default)().hours() * 60 + (0, moment_1.default)().minutes();
}
function getCurrentMinute() {
    return (0, moment_1.default)().minutes() === 0 ? 60 : (0, moment_1.default)().minutes();
}
function getRemainingMinutes(currentMinute, interval) {
    const remainder = currentMinute % interval;
    return remainder === 0 ? 0 : interval - remainder;
}
function getPM2Processes() {
    const now = Date.now();
    if (now - pm2Cache.lastUpdate < pm2Cache.ttl && pm2Cache.processes.length > 0) {
        return pm2Cache.processes;
    }
    try {
        const output = (0, child_process_1.execSync)('pm2 jlist', { encoding: 'utf8' });
        pm2Cache.processes = JSON.parse(output);
        pm2Cache.lastUpdate = now;
        return pm2Cache.processes;
    }
    catch (error) {
        console.error(`${getTimestamp()} ❌ Failed to get PM2 list:`, error.message);
        return null;
    }
}
function getMyPM2Name(processes, myPid) {
    const me = processes.find(p => p.pid === myPid);
    return me?.name || process.env.PM2_NAME || 'unknown';
}
function getFirstPidOfName(processes, name) {
    const matches = processes
        .filter(p => p.name === name && p.pm2_env.status === 'online');
    return matches[0]?.pid || process.pid;
}
function updateProcessState() {
    const myPid = process.pid;
    const processes = getPM2Processes();
    const isRunningUnderPM2 = !!process.env.pm_id;
    if (processes === null) {
        processState.pm2Name = process.env.PM2_NAME || 'unknown';
        if (isRunningUnderPM2) {
            processState.pm2List = [];
            processState.firstProcessPid = -1;
            processState.isFirstProcess = false;
            console.error(`${getTimestamp()} ⚠️  Could not verify PM2 leadership; skipping leader role on this instance to avoid duplicate cron execution.`);
        }
        else {
            processState.pm2List = [myPid];
            processState.firstProcessPid = myPid;
            processState.isFirstProcess = true;
        }
    }
    else {
        processState.pm2Name = getMyPM2Name(processes, myPid);
        const sameNameProcesses = processes.filter(p => p.name === processState.pm2Name && p.pm2_env.status === 'online');
        processState.pm2List = sameNameProcesses.map(p => p.pid);
        processState.firstProcessPid = getFirstPidOfName(processes, processState.pm2Name);
        processState.isFirstProcess = processState.firstProcessPid === myPid;
    }
    console.log(`   ⬜ Instance: ${instanceId}.${processState.pm2Name} (PID: ${myPid}), First PID: ${processState.firstProcessPid}`);
}
function configureTimingSchedules() {
    const timingSchedule = {};
    ['isonline', 'nrefer'].forEach(service => {
        timingSchedule[service] = {
            version: global.appDetail.version,
            apiSubVersion: global.appDetail.subVersion,
            autosend: false,
            minute: 0
        };
    });
    configureService(timingSchedule, 'isonline', 'IS_AUTO_SEND', 'IS_AUTO_SEND_EVERY_MINUTE', 10, true);
    configureService(timingSchedule, 'nrefer', 'NREFER_AUTO_SEND', 'NREFER_AUTO_SEND_EVERY_MINUTE', 5, false);
    return timingSchedule;
}
function configureService(timingSchedule, serviceName, autoSendEnvVar, minuteEnvVar, minMinutes, normalizeHour) {
    timingSchedule[serviceName].autosend = +process.env[autoSendEnvVar] === 1 || false;
    const parsedMinute = process.env[minuteEnvVar] ? parseInt(process.env[minuteEnvVar]) : 0;
    timingSchedule[serviceName].minute = Number.isNaN(parsedMinute) ? 0 : parsedMinute;
    if (normalizeHour && timingSchedule[serviceName].hour > 23) {
        timingSchedule[serviceName].hour = timingSchedule[serviceName].hour % 23;
    }
    timingSchedule[serviceName].minute += (timingSchedule[serviceName].hour || 0) * 60;
    timingSchedule[serviceName].minute =
        timingSchedule[serviceName].minute < minMinutes ? minMinutes : timingSchedule[serviceName].minute;
    if (timingSchedule[serviceName].minute <= 0) {
        timingSchedule[serviceName].autosend = false;
    }
}
function logScheduledServices(timingSchedule) {
    Object.entries(timingSchedule).forEach(([service, config]) => {
        if (config.autosend) {
            console.log(`${getTimestamp()} crontab ${service} start every ${config.minute} (minute) from midnight.`);
        }
    });
}
async function runJob(jobName, jobFn, ...args) {
    if (jobQueue[jobName]?.isRunning) {
        return;
    }
    try {
        jobQueue[jobName] = { isRunning: true };
        await jobFn(...args);
        jobQueue[jobName] = { isRunning: false, lastRun: (0, moment_1.default)() };
    }
    catch (error) {
        console.error(`${getTimestamp()} Error in job ${jobName}:`, error);
        jobQueue[jobName] = { isRunning: false };
    }
}
function logJobStatus() {
    Object.entries(jobQueue).forEach(([jobName, state]) => {
        if (state.lastRun) {
            console.log(`${getTimestamp()} Last process time '${jobName}' ${state.lastRun.format('HH:mm:ss')}`);
            console.log('-'.repeat(70));
        }
    });
}
async function doAutoSend(req, res, serviceName, functionName, timingSchedule) {
    if (!processState.isFirstProcess)
        return;
    const now = (0, moment_1.default)().locale('th').format('HH:mm:ss');
    const db = serviceName === 'isonline' ? global.dbISOnline : global.dbHIS;
    console.log(`${now} start cronjob '${serviceName}' on PID ${process.pid}`);
    if (serviceName !== 'nrefer') {
        await require(functionName)(req, res, db, timingSchedule[serviceName]);
    }
}
async function getmophUrl() {
    global.mophService = await require('./routes/main/crontab')(global.mophService, {});
}
async function cronjob(fastify) {
    const startupAt = Date.now();
    console.info(`${getTimestamp()} Cronjob plugin init start for hospcode ${process.env.HOSPCODE || 'unknown'}`);
    try {
        hospitalConfig = await withTimeout(moph_starter_1.default.getMophConfig({
            purpose: 'cronjob-startup',
            timeoutMs: cronjobStartupTimeoutMs
        }), cronjobStartupTimeoutMs, 'cronjob startup config fetch');
        console.info(`${getTimestamp()} Cronjob startup config ready in ${Date.now() - startupAt}ms`);
    }
    catch (error) {
        hospitalConfig = null;
        console.error(`${getTimestamp()} Cronjob startup config unavailable after ${Date.now() - startupAt}ms: ${getErrorMessage(error)}. Continuing startup without blocking cron registration.`);
    }
    updateProcessState();
    const secondNow = (0, moment_1.default)().seconds();
    const timingSch = `${secondNow} * * * * *`;
    let timeRandom = 10 + (Math.ceil(Math.random() * 10) || 1);
    let hourRandom = Math.ceil(Math.random() * 22) || 1;
    const timingSchedule = configureTimingSchedules();
    if (processState.isFirstProcess) {
        console.log(`${getTimestamp()} Start API for Hospcode ${process.env.HOSPCODE}`);
        console.log(`   ⏰ Random time config:`);
        console.log(`      - Alive/Alert: Every ${timeRandom} minutes`);
        console.log(`      - Bed Occupancy: At minute ${timeRandom}`);
        console.log(`      - Ward/Bed Update: At ${hourRandom}:${timeRandom}:${secondNow}`);
        logScheduledServices(timingSchedule);
    }
    let startupTimeout;
    if (processState.isFirstProcess) {
        startupTimeout = setTimeout(() => {
            (0, moph_erp_1.updateAlive)();
            (0, moph_erp_1.sendWardName)();
            (0, moph_erp_1.sendBedNo)();
        }, 10000);
    }
    let minuteCount = 0;
    const scheduledTask = cron.schedule(timingSch, async (req, res) => {
        minuteCount++;
        const minuteSinceLastNight = getMinutesSinceMidnight();
        const minuteNow = (0, moment_1.default)().get('minute');
        if (processState.isFirstProcess) {
            if (minuteSinceLastNight > 0 && minuteSinceLastNight % 2 === 1) {
                logJobStatus();
            }
            if (minuteNow != 0 && minuteNow % timeRandom == 0) {
                (0, moph_erp_1.updateAlive)();
                (0, moph_alert_1.mophAlertSurvey)();
            }
            if (minuteSinceLastNight > 0 && minuteSinceLastNight % 2 == 0) {
                (0, moph_erp_1.erpAdminRequest)();
            }
            if (minuteNow == timeRandom) {
                (0, moph_erp_1.sendBedOccupancy)();
            }
            if (!onProcess?.mophAppointment && minuteSinceLastNight > 0 && minuteSinceLastNight % timeRandom == 0) {
                onProcess.mophAppointment = true;
                moph_appointment_1.default.process()
                    .catch((error) => console.error(`${getTimestamp()} Error in job mophAppointment:`, getErrorMessage(error)))
                    .finally(() => { onProcess.mophAppointment = false; });
            }
            if (!onProcess?.mophIot && minuteSinceLastNight > 0 && minuteSinceLastNight % timeRandom == 0) {
                onProcess.mophIot = true;
                moph_iot_1.default.processIoT()
                    .catch((error) => console.error(`${getTimestamp()} Error in job mophIot:`, getErrorMessage(error)))
                    .finally(() => { onProcess.mophIot = false; });
            }
            if ((0, moment_1.default)().hour() == hourRandom && minuteNow == timeRandom) {
                console.log(`   --> 📅 Daily Task: Executing Ward Name & Bed No...`);
                (0, moph_erp_1.sendWardName)();
                (0, moph_erp_1.sendBedNo)();
            }
            if ((0, moment_1.default)().hour() == 1 && minuteNow == timeRandom) {
            }
            if (timingSchedule['nrefer'].autosend &&
                minuteSinceLastNight % timingSchedule['nrefer'].minute === 0) {
                if ((0, moment_1.default)().hour() % 2 === 0 && (0, moment_1.default)().minute() === 56) {
                    runJob('sendNReferIPD', async () => {
                        await referCrontab.processSend(req, res, global.dbHIS, {
                            ...timingSchedule['nrefer'],
                            service: 'ipdChecking'
                        });
                    });
                }
                runJob('sendNRefer', async () => {
                    await referCrontab.processSend(req, res, global.dbHIS, timingSchedule['nrefer']);
                });
            }
            if (timingSchedule['isonline'].autosend &&
                minuteSinceLastNight % timingSchedule['isonline'].minute === 0) {
                runJob('sendISOnline', async () => {
                    await doAutoSend(req, res, 'isonline', './routes/isonline/crontab', timingSchedule);
                });
            }
            if (minuteNow === 0 || minuteNow === 60) {
                runJob('getmophUrl', getmophUrl);
            }
        }
    });
    fastify.addHook('onClose', (instance, done) => {
        if (startupTimeout)
            clearTimeout(startupTimeout);
        scheduledTask?.stop();
        done();
    });
    console.info(`${getTimestamp()} Cronjob plugin registered in ${Date.now() - startupAt}ms`);
}
