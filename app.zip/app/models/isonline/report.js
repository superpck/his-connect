"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IsReportModel = void 0;
exports.buildReportQuery = buildReportQuery;
const moment_1 = __importDefault(require("moment"));
const CODE_PATTERN = /^[A-Za-z0-9_-]{1,20}$/;
function buildReportQuery(reportSql, wrapperSql, columnsGroup, conditions) {
    if (!CODE_PATTERN.test(conditions.hospCode)) {
        throw new Error('Invalid hospital code');
    }
    if (!(0, moment_1.default)(conditions.date1, 'YYYY-MM-DD', true).isValid() || !(0, moment_1.default)(conditions.date2, 'YYYY-MM-DD', true).isValid()) {
        throw new Error('Invalid report date');
    }
    if (conditions.region && !CODE_PATTERN.test(conditions.region)) {
        throw new Error('Invalid region');
    }
    if (conditions.changwat && !CODE_PATTERN.test(conditions.changwat)) {
        throw new Error('Invalid province');
    }
    const bindings = [
        conditions.hospCode,
        `${conditions.date1} 00:00:00`,
        `${conditions.date2} 23:59:59`
    ];
    const dateWhere = 'hosp = ? and adate between ? and ?';
    let sql = reportSql
        .replace(/<where>/gi, `where ${dateWhere}`)
        .replace(/<wheredate>/gi, `${dateWhere} and `);
    if (wrapperSql) {
        sql = wrapperSql.replace(/<sql>/gi, `(${sql})`);
        const locationConditions = [];
        if (conditions.region) {
            locationConditions.push('region = ?');
            bindings.push(conditions.region);
        }
        if (conditions.changwat) {
            locationConditions.push('changwatcode = ?');
            bindings.push(conditions.changwat);
        }
        if (locationConditions.length) {
            sql += ` where ${locationConditions.join(' and ')}`;
        }
        if (columnsGroup) {
            sql += ` group by ${columnsGroup}`;
        }
    }
    return { sql, bindings };
}
class IsReportModel {
    getReport1(knex, reportCond) {
        let date1 = reportCond?.date1 + ' 00:00:00';
        let date2 = reportCond?.date2 + ' 23:59:59';
        let Sql = `
      select b.code, b.name as reportname, c.*, h.changwatcode, h.region
      from (select case when a.icdcause between 'W00' and 'W19' then '02'
      when a.icdcause between 'W20' and 'W49' then '03'
      when a.icdcause between 'W50' and 'W64' then '04'
      when a.icdcause between 'W65' and 'W74' then '05'
      when a.icdcause between 'W75' and 'W84' then '06'
      when a.icdcause between 'W85' and 'W99' then '07'
      when a.icdcause between 'X00' and 'X09' then '08'
      when a.icdcause between 'X10' and 'X19' then '09'
      when a.icdcause between 'X20' and 'X29' then '10'
      when a.icdcause between 'X30' and 'X39' then '11'
      when a.icdcause between 'X40' and 'X49' then '12'
      when a.icdcause between 'X50' and 'X57' then '13'
      when a.icdcause between 'X58' and 'X59' then '14'
      when a.icdcause between 'X60' and 'X84' then '15'
      when a.icdcause between 'X85' and 'Y09' then '16'
      when a.icdcause between 'Y10' and 'Y34' then '17'
      when a.icdcause between 'Y35' and 'Y36' then '18'
      when a.icdcause = 'N' then '19'
      else '01' end cause19, count(a.id) as cases
      , count(if(a.staer = '1',1,null)) as dba
      , count(if(a.staer between '2' and '5',1,null)) as outcome
      , count(if(a.staer = '6',1,null)) as dead
      , count(if(a.staer = '7',1,null)) as admit
      , a.hosp, date_format(a.adate,'%Y-%m-%d') as dateaccident ` +
            'from `is` a ' +
            '<where> group by cause19, dateaccident, a.hosp) c right join report_template b on c.cause19 = b.code ' +
            `join lib_hospcode h on c.hosp = h.off_id
      order by b.code`;
        return knex.raw(Sql);
    }
    getReport(knex, reportID) {
        return knex('*')
            .from('report')
            .where('id', '=', reportID);
    }
    getData(knex, sql, bindings) {
        return knex.raw(sql, bindings);
    }
    selectSql(knex, tableName, selectText, whereText, groupBy, orderBy) {
        let sql = 'select ' + selectText + ' from ' + tableName;
        if (whereText != '') {
            sql = sql + ' where ' + whereText;
        }
        if (groupBy != '') {
            sql = sql + ' group by ' + groupBy;
        }
        if (orderBy != '') {
            sql = sql + ' order by ' + orderBy;
        }
        sql = sql + ' limit 0,500';
        return knex.raw(sql);
    }
}
exports.IsReportModel = IsReportModel;
